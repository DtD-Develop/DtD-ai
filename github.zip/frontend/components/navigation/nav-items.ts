export const navItems = [
  { title: "Dashboard", href: "/dashboard" },
  { title: "Chat", href: "/chat" },
  { title: "Upload", href: "/upload" },
  { title: "KB Table", href: "/kb" },
  { title: "API Logs", href: "/api-logs" },
];
